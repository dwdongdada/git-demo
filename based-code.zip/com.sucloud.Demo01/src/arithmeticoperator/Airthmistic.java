package arithmeticoperator;

public class Airthmistic {
    public static void main(String[] args) {
        System.out.println("你好");
        byte b1 = 10;
        byte b2 = 10;
        //如果数据过大,超出取值范围的,就会很难办
        byte result = (byte) (b1+b2);
        //强制转换
        System.out.println(3.7+"abc");
        System.out.println(result);

        System.out.println('中' + "abc"+ true);
    }
}
